GT8 Audio Controller 0.2.0 - Android Studio 源码

本版改进：
- 启动时枚举系统可见的 AudioEffect 描述符。
- 使用 AudioTrack 创建独立测试音频流，再用该流的 session ID 创建 Equalizer、BassBoost、Virtualizer。
- 三种效果独立初始化；某一种不可用不会阻止其他效果测试。
- EQ 按设备返回的频段数和增益范围动态生成滑块。
- 停止时释放 AudioTrack 和效果实例。

构建：
- Android Studio / Gradle
- Android Gradle Plugin 8.7.3
- Android SDK Platform 35
- JDK 17

在 Android Studio 中打开本目录，等待 Gradle Sync，然后 Build > Build APK(s)。

重要限制：
1. 本程序只处理自身产生的 220 Hz 测试音频；不会调节 YouTube、游戏、音乐播放器等其他应用。
2. Android AudioEffect session API 的创建成功与否要在 GT8 真机验证。
3. 即使实例创建成功，也不证明效果一定被设备 DSP 接受或声音输出确实改变。
4. 不使用 session 0 全局插入方式；不修改系统配置、不替换 vendor 库。
5. 不是 Dolby Atmos，也不宣称全局增强。

真机验证标准：
- 页面能列出可见效果描述符；
- 点击启动后显示 EQ/BassBoost/Virtualizer 各自创建结果；
- 拖动滑块时无参数异常；
- 停止后声音停止，效果实例释放。
