package com.gt8.audio;

import android.app.Activity;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.Virtualizer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity {
    private AudioTrack track;
    private Equalizer equalizer;
    private BassBoost bassBoost;
    private Virtualizer virtualizer;
    private volatile boolean playing = false;
    private Thread toneThread;
    private TextView status;
    private LinearLayout controls;
    private Button startButton;
    private Button stopButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        showEffectInventory();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20, 18, 20, 18);

        TextView heading = new TextView(this);
        heading.setText("GT8 原厂音效控制器");
        heading.setTextSize(22);
        page.addView(heading);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, 12, 0, 12);
        page.addView(status);

        startButton = new Button(this);
        startButton.setText("启动测试音频");
        startButton.setOnClickListener(v -> startTest());
        page.addView(startButton);

        stopButton = new Button(this);
        stopButton.setText("停止并释放");
        stopButton.setEnabled(false);
        stopButton.setOnClickListener(v -> stopTest());
        page.addView(stopButton);

        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(controls);
        page.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(page);
    }

    private void showEffectInventory() {
        StringBuilder report = new StringBuilder();
        report.append("Android AudioEffect 接口检测\n");
        try {
            AudioEffect.Descriptor[] descriptors = AudioEffect.queryEffects();
            if (descriptors == null || descriptors.length == 0) {
                report.append("系统未返回可枚举的效果描述符。\n");
            } else {
                for (AudioEffect.Descriptor d : descriptors) {
                    String n = d.name == null ? "" : d.name.toLowerCase(Locale.ROOT);
                    if (n.contains("equal") || n.contains("bass") ||
                        n.contains("virtual") || n.contains("oplus") ||
                        n.contains("spatial")) {
                        report.append("• ").append(d.name)
                              .append(" / ").append(d.implementor).append("\n");
                    }
                }
            }
        } catch (Throwable t) {
            report.append("枚举失败：").append(t.getClass().getSimpleName()).append("\n");
        }
        report.append("\n注意：这里只枚举系统可见效果，不代表它们已启用。");
        status.setText(report.toString());
    }

    private void startTest() {
        if (playing) return;
        controls.removeAllViews();
        try {
            final int sampleRate = 48000;
            int minBuffer = AudioTrack.getMinBufferSize(sampleRate,
                    AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT);
            if (minBuffer <= 0) throw new IllegalStateException("AudioTrack buffer 不可用");

            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(sampleRate)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(Math.max(minBuffer * 2, 8192))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();

            if (track.getState() != AudioTrack.STATE_INITIALIZED)
                throw new IllegalStateException("AudioTrack 初始化失败");

            int sessionId = track.getAudioSessionId();
            StringBuilder result = new StringBuilder("测试音频 Session: ")
                    .append(sessionId).append("\n");

            try {
                equalizer = new Equalizer(0, sessionId);
                equalizer.setEnabled(true);
                result.append("EQ：已创建，频段 ")
                      .append(equalizer.getNumberOfBands()).append("\n");
                addEqualizerSliders();
            } catch (Throwable t) {
                result.append("EQ：不可用（").append(t.getClass().getSimpleName()).append("）\n");
                releaseEqualizer();
            }

            try {
                bassBoost = new BassBoost(0, sessionId);
                bassBoost.setEnabled(true);
                result.append("BassBoost：已创建；强度调节 ")
                      .append(bassBoost.getStrengthSupported() ? "支持" : "不支持")
                      .append("\n");
                addStrengthSlider("低音增强", bassBoost.getRoundedStrength(),
                        value -> bassBoost.setStrength((short)value));
            } catch (Throwable t) {
                result.append("BassBoost：不可用（").append(t.getClass().getSimpleName()).append("）\n");
                releaseBass();
            }

            try {
                virtualizer = new Virtualizer(0, sessionId);
                virtualizer.setEnabled(true);
                result.append("Virtualizer：已创建；强度调节 ")
                      .append(virtualizer.getStrengthSupported() ? "支持" : "不支持")
                      .append("\n");
                addStrengthSlider("虚拟环绕", virtualizer.getRoundedStrength(),
                        value -> virtualizer.setStrength((short)value));
            } catch (Throwable t) {
                result.append("Virtualizer：不可用（").append(t.getClass().getSimpleName()).append("）\n");
                releaseVirtualizer();
            }

            playing = true;
            track.play();
            toneThread = new Thread(() -> generateTone(sampleRate), "GT8-Audio-Test");
            toneThread.start();
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            status.setText(result.toString() +
                    "\n这是本应用测试音频的效果，不会改变其他应用的声音。");
        } catch (Throwable t) {
            stopTest();
            status.setText("启动失败：" + t.getClass().getSimpleName() +
                    (t.getMessage() == null ? "" : " - " + t.getMessage()));
        }
    }

    private void addEqualizerSliders() {
        if (equalizer == null) return;
        short[] range = equalizer.getBandLevelRange();
        short bands = equalizer.getNumberOfBands();
        for (short i = 0; i < bands; i++) {
            final short band = i;
            final int min = range[0], max = range[1];
            int centerHz = equalizer.getCenterFreq(band);
            String label = centerHz >= 1000
                    ? String.format(Locale.US, "%.1f kHz", centerHz / 1000f)
                    : centerHz + " Hz";
            addSlider("EQ " + label, min, max, equalizer.getBandLevel(band),
                    value -> { if (equalizer != null) equalizer.setBandLevel(band, (short)value); },
                    true);
        }
    }

    private interface Change { void apply(int value); }

    private void addStrengthSlider(String title, int initial, Change change) {
        addSlider(title, 0, 1000, initial, change, false);
    }

    private void addSlider(String title, int min, int max, int initial,
                           Change change, boolean showDb) {
        TextView label = new TextView(this);
        label.setText(formatValue(title, initial, showDb));
        controls.addView(label);

        SeekBar seek = new SeekBar(this);
        seek.setMax(Math.max(1, max - min));
        seek.setProgress(Math.max(0, Math.min(seek.getMax(), initial - min)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int value = progress + min;
                label.setText(formatValue(title, value, showDb));
                if (fromUser) {
                    try { change.apply(value); }
                    catch (Throwable t) {
                        status.setText("设备拒绝该参数：" + t.getClass().getSimpleName());
                    }
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        controls.addView(seek);
    }

    private String formatValue(String title, int value, boolean db) {
        if (db) return title + " : " + String.format(Locale.US, "%.1f dB", value / 100f);
        return title + " : " + value + " / 1000";
    }

    private void generateTone(int rate) {
        short[] samples = new short[1024 * 2];
        double phase = 0;
        while (playing && track != null) {
            for (int i = 0; i < 1024; i++) {
                short s = (short)(Math.sin(phase) * 4500);
                phase += 2.0 * Math.PI * 220.0 / rate;
                if (phase >= 2.0 * Math.PI) phase -= 2.0 * Math.PI;
                samples[i * 2] = s;
                samples[i * 2 + 1] = s;
            }
            AudioTrack current = track;
            if (current == null) break;
            try {
                int written = current.write(samples, 0, samples.length);
                if (written < 0) break;
            } catch (Throwable ignored) { break; }
        }
    }

    private void stopTest() {
        playing = false;
        AudioTrack oldTrack = track;
        track = null;
        if (oldTrack != null) {
            try { oldTrack.pause(); } catch (Throwable ignored) {}
            try { oldTrack.flush(); } catch (Throwable ignored) {}
            try { oldTrack.stop(); } catch (Throwable ignored) {}
            try { oldTrack.release(); } catch (Throwable ignored) {}
        }
        releaseEqualizer();
        releaseBass();
        releaseVirtualizer();
        if (startButton != null) startButton.setEnabled(true);
        if (stopButton != null) stopButton.setEnabled(false);
    }

    private void releaseEqualizer() {
        if (equalizer != null) { try { equalizer.release(); } catch (Throwable ignored) {} }
        equalizer = null;
    }
    private void releaseBass() {
        if (bassBoost != null) { try { bassBoost.release(); } catch (Throwable ignored) {} }
        bassBoost = null;
    }
    private void releaseVirtualizer() {
        if (virtualizer != null) { try { virtualizer.release(); } catch (Throwable ignored) {} }
        virtualizer = null;
    }

    @Override protected void onDestroy() {
        stopTest();
        super.onDestroy();
    }
}
